package com.cookit.user.vo;

import org.springframework.stereotype.Component;

@Component("userVO")
public class UserVO {
	private String user_id;
	private enum user_type;
	private String user_id;
	private String user_id;
	private String user_id;
	private String user_id;
	private String user_id;

	
}
