package com.cookit.cart.dao;

public class CartDAO {

}
